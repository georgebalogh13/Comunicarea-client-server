from http.server import HTTPServer, BaseHTTPRequestHandler
from unicodedata import name
from urllib.parse import parse_qs
names_dict = {
    "dan" : {"first_name" : "dan" ,"student_number" : "123", "last_name" :"badea", "median" : 4}
}
            
class RequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.log_message("Incoming GET request...")
        try:
            student_number = parse_qs(self.path[2:])['student_number'][0]
        except:
            self.send_response_to_client(404, 'Incorrect parameters provided')
            self.log_message("Incorrect parameters provided")
            return
 
        for el in names_dict:
            print("iterez")
            print(names_dict[el])
            if student_number == list(names_dict[el].values())[1]:
                print("returnez " + str(names_dict[el]))
                self.send_response_to_client(200, names_dict[el] )
    def do_POST(self):
        self.log_message('Incoming POST request...')
        try:
            first_name = parse_qs(self.path[2:])['first_name'][0]
            last_name = parse_qs(self.path[2:])['last_name'][0]
            student_number = parse_qs(self.path[2:])['student_number'][0]
            median = parse_qs(self.path[2:])['median'][0]
            names_dict[first_name] = {
                "first_name" : first_name,
                "student_number" : student_number,
                "last_name": last_name,
                "median": median
            }
            self.send_response_to_client(200, names_dict)

        except KeyError:
            self.send_response_to_client(404, 'Incorrect parameters provided')
            self.log_message("Incorrect parameters provided")
             
    def send_response_to_client(self, status_code, data):
        # Send OK status
        self.send_response(status_code)
        # Send headers
        self.send_header('Content-type', 'text/plain')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
     
        # Send the response
        self.wfile.write(str(data).encode())
 
server_address = ('127.0.0.1', 8080)
http_server = HTTPServer(server_address, RequestHandler)
http_server.serve_forever()